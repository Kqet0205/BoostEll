@echo off
title BoostEll for Minecraft 1.12.2 (V3)
echo ----------------------------------
echo BoostEll for Minecraft 1.12.2 (V3)
echo ----------------------------------
echo Start?
pause
use sb.bat
echo sb.bat
i minecraft.1.12.2.boostellv3.fps+
(install d "boostell"
=boostell://install.be/v3/all
use,
install bin
=bin
use,
install settings
=fps.jar
use
)
cls
start sb.bat
start start_message.vbs
