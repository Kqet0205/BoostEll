@echo off
title BoostEll for Minecraft 1.12.2 (V1)
echo ----------------------------------
echo BoostEll for Minecraft 1.12.2 (V1)
echo ----------------------------------
echo Start?
pause
use sb.bat
echo sb.bat
pip minecraft.1.12.2.boostellv1.fps+
(install d "boostell"
=boostell://install.be/v1/all
use)
cls
start sb.bat
start start_message.vbs