@echo off
echo import minecraft_launcher_lib import subprocess import sys minecraft_directory = ".minecraft" version = "1.12.2" minecraft_launcher_lib.install.install_minecraft_version(version, minecraft_directory) command = minecraft_launcher_lib.command.get_minecraft_command(version, minecraft_directory, options) subprocess.call(command)
echo install default "boostellv1"
exit